{
	"geoCodeError":"Ups! Der var et problem med at finde adressen! Prøv venligst igen.",
	"locationSet":"Adresse sat til",
	"resetTxt":"Nulstil position"
}