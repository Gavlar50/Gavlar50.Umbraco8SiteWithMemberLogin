{
	"geoCodeError":"Oeps! De locatie van het adres kan momenteel niet opgezocht worden!",
	"locationSet":"Locatie ingesteld op",
	"resetTxt":"Positie resetten"
}