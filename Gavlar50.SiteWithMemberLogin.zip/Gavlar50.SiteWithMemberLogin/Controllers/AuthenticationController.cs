﻿using System;
using System.Web.Mvc;
using System.Web.Security;
using Umbraco.Web.Mvc;
using Gavlar50.SiteWithMemberLogin.Models;

namespace Gavlar50.SiteWithMemberLogin.Controllers
{
    public class AuthenticationController : SurfaceController
    {
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (Membership.ValidateUser(model.Username, model.Password))
                {
                    FormsAuthentication.SetAuthCookie(model.Username, false); // set to true for "remember me."
                    return Redirect(model.ReturnUrl.IndexOf("login", StringComparison.InvariantCulture) > 0 ? "/" : model.ReturnUrl);
                }
                ModelState.AddModelError(String.Empty, "Invalid Username or password.");
            }
            return CurrentUmbracoPage();
        }

        [HttpGet]
        public void Logout()
        {
            FormsAuthentication.SignOut();
            Response.Redirect("/", true);
        }
    }
}