{
	"geoCodeError":"Oops! Having trouble geocoding specified address! Please try again.",
	"locationSet":"Location set to",
	"resetTxt":"Reset position"
}